function showDetails(id) {
    document.querySelectorAll('.details-card').forEach(card => {
        card.classList.remove('active');
    });
    document.getElementById(id).classList.add('active');
}

document.addEventListener("DOMContentLoaded", function () {
    const storedXray = localStorage.getItem("patient1_xray");
    const storedPrediction = localStorage.getItem("patient1_prediction");

    if (storedXray) {
        document.getElementById("historyXray").src = storedXray;
    }
    if (storedPrediction) {
        document.getElementById("historyPrediction").innerText = storedPrediction;
    }
});
