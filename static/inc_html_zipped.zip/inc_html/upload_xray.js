// Handle CSV File Upload
const csvUpload = document.getElementById('csvUpload');
const csvPreview = document.getElementById('csvPreview');
const csvForm = document.getElementById('csvForm');

csvForm.addEventListener('submit', function (event) {
    event.preventDefault();

    const file = csvUpload.files[0];

    if (file && file.type === 'text/csv') {
        const reader = new FileReader();
        reader.onload = function (e) {
            const csvData = e.target.result;
            const rows = csvData.split('\n'); // Split by rows
            const tableBody = csvPreview.querySelector('tbody');
            const tableHeader = csvPreview.querySelector('thead tr');

            // Clear previous table content
            tableBody.innerHTML = '';
            tableHeader.innerHTML = '';

            // Process CSV rows
            rows.forEach((row, rowIndex) => {
                const cells = row.split(','); // Split by commas to get columns
                const tr = document.createElement('tr');
                
                cells.forEach((cell) => {
                    const td = document.createElement('td');
                    td.textContent = cell.trim();
                    tr.appendChild(td);
                });

                // For the first row, add headers
                if (rowIndex === 0) {
                    cells.forEach((header) => {
                        const th = document.createElement('th');
                        th.textContent = header.trim();
                        tableHeader.appendChild(th);
                    });
                } else {
                    tableBody.appendChild(tr);
                }
            });

            // Show the preview table
            csvPreview.style.display = 'table';
        };
        reader.readAsText(file);
    } else {
        alert("Please upload a valid CSV file.");
    }
});
const imageUpload = document.getElementById('imageUpload');
const imagePreview = document.getElementById('imagePreview');

// imageUpload.addEventListener('change', function (event) {
//     const file = event.target.files[0];
//     if (file && file.type.startsWith('image')) {
//         const reader = new FileReader();
//         reader.onload = function (e) {
//             imagePreview.src = e.target.result;
//             imagePreview.style.display = 'block';
//         };
//         reader.readAsDataURL(file);
//     } else {
//         alert("Please upload a valid image file.");
//     }
// });