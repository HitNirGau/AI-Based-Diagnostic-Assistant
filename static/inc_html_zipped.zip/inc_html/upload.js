document.getElementById("imageUpload").addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById("imagePreview").src = e.target.result;
            document.getElementById("imagePreview").style.display = "block";
        };
        reader.readAsDataURL(file);
    }
});

document.getElementById("predictBtn").addEventListener("click", function () {
    const prediction = "Pneumonia detected"; // Example prediction
    document.getElementById("predictionResult").innerText = prediction;
});


